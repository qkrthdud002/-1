#pragma warning(disable : 4996)
#include "���.h" //<stdio.h>

int main() {
	extern int a;
	//int a;
	abc(5);
	printf("extern int a=%d\n", a);
	return 0;
}