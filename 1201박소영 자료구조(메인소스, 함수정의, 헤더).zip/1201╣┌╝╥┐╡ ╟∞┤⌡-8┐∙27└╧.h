#pragma once
#include <stdio.h>
int abc(int);